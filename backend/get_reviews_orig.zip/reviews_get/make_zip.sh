rm get_reviews.zip; zip get_reviews.zip index.js package.json ../index.json
